# Slimme Boodschappen – Android startversie

Dit is een afzonderlijk Android-project voor de boodschappenapp.

## Wat zit in deze eerste basisversie?
- Lokale weeklijst (ISO-weeknummer) met Room-database.
- Product handmatig toevoegen en verwijderen.
- Producten afvinken als gekocht.
- Zoeken op productnaam of EAN.
- EAN/UPC-barcode scannen via Google Play Services Code Scanner.
- Basis voor productprijsvelden en winkelherkomst.

## Nog niet aangesloten
De volgende onderdelen zijn bewust nog niet als werkend gepresenteerd:
- Live productcatalogi en prijzen van Dirk, PLUS, Albert Heijn en Jumbo.
- Automatische productnaam-resolutie via EAN.
- Voorraadfoto's en AI-herkenning.
- Leren van aankoop- en verbruikspatronen.
- Volledige weekarchief-/historie-interface.

Deze onderdelen vereisen aanvullende productdatabronnen, prijsintegraties en de voorraad-/leerlogica.

## APK bouwen via GitHub Actions (zonder Windows-pc)
1. Maak op GitHub een nieuwe lege repository aan, bijvoorbeeld `slimme-boodschappen`.
2. Upload de inhoud van deze ZIP naar de repository (de mapinhoud, niet de ZIP zelf).
3. Open het tabblad **Actions**.
4. Kies **Build Android APK** en druk op **Run workflow**.
5. Na een geslaagde build open je de run en download je bij **Artifacts** `SlimmeBoodschappen-debug`.
6. Pak het artifact uit op je telefoon en installeer `app-debug.apk`. Android kan vragen om installatie vanuit deze bron toe te staan.

## Technische notities
- Package: `nl.slimmeboodschappen`
- Minimaal Android 8.0 (API 26).
- Kotlin, Jetpack Compose, Room en Google ML Kit Code Scanner.
- Scanner gebruikt Google Play Services en kan bij de eerste keer scannen de benodigde module downloaden.

## Belangrijke implementatienotitie
De scanner is bedoeld voor het scannen van EAN/UPC-codes. In de huidige basisversie wordt het gescande nummer aan de lijst toegevoegd als `Onbekend product`; een productcatalogus-koppeling om naam en prijs automatisch op te halen volgt in een latere fase.


## Versie 0.2 – EAN-productherkenning
Na het scannen zoekt de app de barcode op via de Open Food Facts Product API. Als er een match is, vult de app productnaam, merk en inhoud in. Als er geen match of netwerkverbinding is, blijft het product als `Onbekend product` staan. Productprijzen worden hiermee niet opgehaald.
