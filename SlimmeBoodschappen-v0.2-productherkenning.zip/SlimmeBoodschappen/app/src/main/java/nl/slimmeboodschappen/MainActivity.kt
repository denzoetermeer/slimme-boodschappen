package nl.slimmeboodschappen

import android.os.Bundle
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.mlkit.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.launch
import nl.slimmeboodschappen.data.GroceryDatabase
import nl.slimmeboodschappen.data.ShoppingItem
import nl.slimmeboodschappen.data.currentWeekKey
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val scanLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val barcode = com.google.android.gms.mlkit.codescanner.GmsBarcodeScanning
                .getClient(this)
            // The scanner result is read from the result intent by the ML Kit API helper.
            val raw = result.data?.getStringExtra("com.google.mlkit.vision.codescanner.EXTRA_BARCODE")
            if (!raw.isNullOrBlank()) addScannedProduct(raw)
        }
    }

    private fun addScannedProduct(ean: String) {
        lifecycleScope.launch {
            val dao = GroceryDatabase.get(this@MainActivity).shoppingDao()
            val known = dao.findByEan(ean)
            val productName = known?.name ?: lookupProductName(ean) ?: "Onbekend product"
            dao.insert(
                ShoppingItem(
                    weekKey = currentWeekKey(),
                    name = productName,
                    ean = ean,
                    priceCents = known?.priceCents,
                    store = known?.store
                )
            )
        }
    }

    private suspend fun lookupProductName(ean: String): String? = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            val url = URL("https://world.openfoodfacts.org/api/v2/product/$ean?fields=product_name,brands,quantity")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("User-Agent", "SlimmeBoodschappen/0.2 (Android)")
            }
            if (connection.responseCode != HttpURLConnection.HTTP_OK) return@withContext null
            val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            if (json.optInt("status") != 1) return@withContext null
            val product = json.optJSONObject("product") ?: return@withContext null
            val name = product.optString("product_name").trim()
            if (name.isBlank() || name == "null") return@withContext null
            val brand = product.optString("brands").trim()
            val quantity = product.optString("quantity").trim()
            listOf(name, brand, quantity).filter { it.isNotBlank() && it != "null" }.distinct().joinToString(" · ")
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun startScanner() {
        val scanner = GmsBarcodeScanning.getClient(this)
        scanner.startScan()
            .addOnSuccessListener { barcode ->
                val value = barcode.rawValue
                if (!value.isNullOrBlank()) addScannedProduct(value)
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = androidx.compose.ui.graphics.Color(0xFF397B45),
                    secondary = androidx.compose.ui.graphics.Color(0xFFE3B52D),
                    background = androidx.compose.ui.graphics.Color(0xFFF4F5F0)
                )
            ) {
                GroceryScreen(
                    onScan = ::startScanner
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GroceryScreen(onScan: () -> Unit) {
    val context = LocalContext.current
    val dao = remember { GroceryDatabase.get(context).shoppingDao() }
    val week = remember { currentWeekKey() }
    val groceries by dao.itemsForWeek(week).collectAsState(initial = emptyList())
    var newName by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }

    val visibleItems = groceries.filter {
        it.name.contains(search, ignoreCase = true) || (it.ean?.contains(search) == true)
    }
    val purchasedCount = groceries.count { it.purchased }
    val totalCents = groceries.sumOf { (it.priceCents ?: 0) * it.quantity }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Slimme Boodschappen", fontWeight = FontWeight.Bold)
                        Text(week, style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    IconButton(onClick = onScan) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "EAN scannen")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, contentDescription = "Product toevoegen")
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("Deze week", style = MaterialTheme.typography.titleMedium)
                    Text("$purchasedCount van ${groceries.size} producten gekocht")
                    LinearProgressIndicator(
                        progress = { if (groceries.isEmpty()) 0f else purchasedCount.toFloat() / groceries.size },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Bekende subtotaal: ${String.format(Locale("nl", "NL"), "€ %.2f", totalCents / 100.0)}",
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Zoek product of EAN") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onScan, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("EAN scannen")
                }
                OutlinedButton(onClick = { showAdd = true }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Zelf toevoegen")
                }
            }

            if (groceries.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("Je lijst is nog leeg. Scan een barcode of voeg een product toe.")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(visibleItems, key = { it.id }) { item ->
                        GroceryRow(
                            item = item,
                            onToggle = {
                                kotlinx.coroutines.MainScope().launch {
                                    dao.update(item.copy(purchased = !item.purchased))
                                }
                            },
                            onDelete = {
                                kotlinx.coroutines.MainScope().launch { dao.delete(item) }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Product toevoegen") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Productnaam") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val name = newName.trim()
                    if (name.isNotEmpty()) {
                        kotlinx.coroutines.MainScope().launch {
                            dao.insert(ShoppingItem(weekKey = week, name = name))
                        }
                        newName = ""
                        showAdd = false
                    }
                }) { Text("Toevoegen") }
            },
            dismissButton = {
                TextButton(onClick = { showAdd = false }) { Text("Annuleren") }
            }
        )
    }
}

@Composable
private fun GroceryRow(
    item: ShoppingItem,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = item.purchased, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(
                    item.name,
                    fontWeight = FontWeight.SemiBold,
                    color = if (item.purchased) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onSurface
                )
                if (item.ean != null) {
                    Text("EAN: ${item.ean}", style = MaterialTheme.typography.labelSmall)
                }
                if (item.priceCents == null) {
                    Text("Prijs nog niet beschikbaar", style = MaterialTheme.typography.labelSmall)
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Verwijderen")
            }
        }
    }
}
