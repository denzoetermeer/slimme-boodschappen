package nl.slimmeboodschappen.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.temporal.WeekFields
import java.util.Locale

@Entity(tableName = "shopping_items")
data class ShoppingItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val weekKey: String,
    val name: String,
    val ean: String? = null,
    val quantity: Int = 1,
    val purchased: Boolean = false,
    val priceCents: Int? = null,
    val store: String? = null
)

@Dao
interface ShoppingDao {
    @Query("SELECT * FROM shopping_items WHERE weekKey = :week ORDER BY purchased ASC, name COLLATE NOCASE")
    fun itemsForWeek(week: String): Flow<List<ShoppingItem>>

    @Insert
    suspend fun insert(item: ShoppingItem)

    @Update
    suspend fun update(item: ShoppingItem)

    @Delete
    suspend fun delete(item: ShoppingItem)

    @Query("SELECT * FROM shopping_items WHERE ean = :ean ORDER BY id DESC LIMIT 1")
    suspend fun findByEan(ean: String): ShoppingItem?
}

@Database(entities = [ShoppingItem::class], version = 1, exportSchema = false)
abstract class GroceryDatabase : RoomDatabase() {
    abstract fun shoppingDao(): ShoppingDao

    companion object {
        @Volatile private var INSTANCE: GroceryDatabase? = null

        fun get(context: Context): GroceryDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    GroceryDatabase::class.java,
                    "slimme-boodschappen.db"
                ).build().also { INSTANCE = it }
            }
    }
}

fun currentWeekKey(): String {
    val date = LocalDate.now()
    val week = date.get(WeekFields.ISO.weekOfWeekBasedYear())
    val year = date.get(WeekFields.ISO.weekBasedYear())
    return "%04d-W%02d".format(year, week)
}
