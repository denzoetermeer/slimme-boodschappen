# Vaste Android release-ondertekening

Deze broncode is voorbereid voor een vaste release-keystore. Gebruik steeds dezelfde keystore voor alle volgende APK-versies; verlies of vervang hem niet, anders kan Android de app niet als update installeren.

Maak in GitHub bij **Settings → Secrets and variables → Actions** deze repository secrets aan:

- `KEYSTORE_BASE64`: volledige inhoud van het bestand `release-keystore-base64.txt` uit het aparte signing-pakket.
- `KEYSTORE_PASSWORD`: wachtwoord uit `signing-info.txt`.
- `KEY_ALIAS`: alias uit `signing-info.txt`.
- `KEY_PASSWORD`: wachtwoord uit `signing-info.txt` (bij deze sleutel gelijk aan het keystore-wachtwoord).

Daarna bouwt **Actions → Build Android APK → Run workflow** een ondertekende release-APK.

## Belangrijk
- Bewaar `release-key.jks` en `signing-info.txt` op een veilige plek, los van de openbare GitHub-repository.
- Upload de keystore of wachtwoorden nooit naar een openbare repository.
- Door de overstap van de oude tijdelijke debug-ondertekening naar deze vaste release-sleutel is waarschijnlijk één keer verwijderen van de huidige app nodig. Daarna moeten updates met deze vaste sleutel over de vorige release kunnen worden geïnstalleerd.
- Automatische updatecontrole in de app is nog niet geactiveerd: daarvoor is de URL van de GitHub-repository met de releases nodig.
