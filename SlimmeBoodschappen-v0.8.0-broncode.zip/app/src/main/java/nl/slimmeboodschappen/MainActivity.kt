package nl.slimmeboodschappen

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import coil.compose.AsyncImage
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.mlkit.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.launch
import nl.slimmeboodschappen.data.GroceryDatabase
import nl.slimmeboodschappen.data.ShoppingItem
import nl.slimmeboodschappen.data.currentWeekKey
import java.util.Locale
import java.net.URLEncoder

class MainActivity : ComponentActivity() {
    private val scanLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val barcode = com.google.android.gms.mlkit.codescanner.GmsBarcodeScanning
                .getClient(this)
            // The scanner result is read from the result intent by the ML Kit API helper.
            val raw = result.data?.getStringExtra("com.google.mlkit.vision.codescanner.EXTRA_BARCODE")
            if (!raw.isNullOrBlank()) addScannedProduct(raw)
        }
    }

    private fun addScannedProduct(ean: String) {
        lifecycleScope.launch {
            val dao = GroceryDatabase.get(this@MainActivity).shoppingDao()
            val known = dao.findByEan(ean)
            val lookup = if (known == null) lookupProductName(ean) else null
            val parts = lookup?.split("||IMAGE:", limit = 2)
            val productName = known?.name ?: parts?.firstOrNull() ?: "Onbekend product"
            val imageUrl = known?.imageUrl ?: parts?.getOrNull(1)
            dao.insert(ShoppingItem(weekKey = currentWeekKey(), name = productName, ean = ean,
                priceCents = known?.priceCents, store = known?.store, imageUrl = imageUrl))
        }
    }

    private suspend fun lookupProductName(ean: String): String? = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            val url = URL("https://world.openfoodfacts.org/api/v2/product/$ean?fields=product_name,brands,quantity,image_front_small_url,image_front_url")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("User-Agent", "SlimmeBoodschappen/0.2 (Android)")
            }
            if (connection.responseCode != HttpURLConnection.HTTP_OK) return@withContext null
            val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            if (json.optInt("status") != 1) return@withContext null
            val product = json.optJSONObject("product") ?: return@withContext null
            val name = product.optString("product_name").trim()
            if (name.isBlank() || name == "null") return@withContext null
            val brand = product.optString("brands").trim()
            val quantity = product.optString("quantity").trim()
            val image = product.optString("image_front_small_url").ifBlank { product.optString("image_front_url") }
            val details = listOf(name, brand, quantity).filter { it.isNotBlank() && it != "null" }.distinct().joinToString(" · ")
            if (image.isNotBlank() && image != "null") "$details||IMAGE:$image" else details
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    private suspend fun lookupDeal(item: ShoppingItem): ShoppingItem? = withContext(Dispatchers.IO) {
        val retailers = listOf("dirk", "aldi", "plus", "albert-heijn", "jumbo")
        // Search Dirk first; only fall back to the other chains if no Dirk deal matches.
        for (retailer in retailers) {
            var connection: HttpURLConnection? = null
            try {
                val q = URLEncoder.encode(item.ean ?: item.name, "UTF-8")
                val url = URL("https://www.prijsprofeet.nl/api/v1/search?q=$q&retailer=$retailer&page_size=20")
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10000
                    readTimeout = 10000
                    setRequestProperty("User-Agent", "SlimmeBoodschappen/0.4 (Android)")
                }
                if (connection.responseCode != HttpURLConnection.HTTP_OK) continue
                val root = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                val rows = root.optJSONArray("results")
                    ?: root.optJSONArray("items")
                    ?: root.optJSONArray("products")
                    ?: continue
                for (i in 0 until rows.length()) {
                    val row = rows.optJSONObject(i) ?: continue
                    val rowEan = row.optString("ean")
                    val rowName = row.optString("name", row.optString("product_name"))
                    if (!item.ean.isNullOrBlank() && rowEan == item.ean ||
                        item.ean.isNullOrBlank() && rowName.contains(item.name, ignoreCase = true)) {
                        val price = row.optDouble("price", Double.NaN)
                        val original = row.optDouble("original_price", Double.NaN)
                        val status = row.optString("promotion_status")
                        val active = row.optBoolean("is_current_deal", false) ||
                            status == "active" || row.optBoolean("is_deal", false)
                        if (price.isFinite() && price > 0 && active) {
                            val validUntil = row.optString("valid_until").takeUnless { it.isBlank() || it == "null" }
                            return@withContext item.copy(
                                priceCents = (price * 100).toInt(),
                                store = retailer.replace("-", " ").replaceFirstChar { it.uppercase() },
                                isDeal = true,
                                originalPriceCents = if (original.isFinite() && original > price) (original * 100).toInt() else null,
                                dealValidUntil = validUntil
                            )
                        }
                    }
                }
            } catch (_: Exception) {
                // Continue with the next retailer if a source is unavailable.
            } finally {
                connection?.disconnect()
            }
        }
        null
    }

    private fun startScanner() {
        val scanner = GmsBarcodeScanning.getClient(this)
        scanner.startScan()
            .addOnSuccessListener { barcode ->
                val value = barcode.rawValue
                if (!value.isNullOrBlank()) addScannedProduct(value)
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = androidx.compose.ui.graphics.Color(0xFF397B45),
                    secondary = androidx.compose.ui.graphics.Color(0xFFE3B52D),
                    background = androidx.compose.ui.graphics.Color(0xFFF4F5F0)
                )
            ) {
                GroceryScreen(
                    onScan = ::startScanner
                )
            }
        }
    }
}

private suspend fun lookupImageByName(name: String): String? = withContext(Dispatchers.IO) {
    var connection: HttpURLConnection? = null
    try {
        val q = URLEncoder.encode(name, "UTF-8")
        // Search several Open Food Facts matches instead of trusting the first result,
        // which often has no photo or is a different product variant.
        val url = URL("https://world.openfoodfacts.org/cgi/search.pl?search_terms=$q&search_simple=1&action=process&json=1&page_size=10&fields=product_name,product_name_nl,generic_name,brands,quantity,image_front_small_url,image_front_url")
        connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 12000
            setRequestProperty("User-Agent", "SlimmeBoodschappen/0.8 (Android)")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Accept-Language", "nl-NL,nl;q=0.9,en;q=0.7")
        }
        if (connection.responseCode != HttpURLConnection.HTTP_OK) return@withContext null
        val rows = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            .optJSONArray("products") ?: return@withContext null
        val wanted = name.lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 2 }.toSet()
        var bestUrl: String? = null
        var bestScore = -1
        for (i in 0 until rows.length()) {
            val product = rows.optJSONObject(i) ?: continue
            val image = product.optString("image_front_small_url")
                .ifBlank { product.optString("image_front_url") }
                .takeUnless { it.isBlank() || it == "null" } ?: continue
            val searchable = listOf("product_name", "product_name_nl", "generic_name", "brands", "quantity")
                .map { product.optString(it) }.joinToString(" ").lowercase(Locale.ROOT)
            val score = wanted.count { searchable.contains(it) }
            if (score > bestScore) {
                bestScore = score
                bestUrl = image
            }
        }
        bestUrl
    } catch (_: Exception) { null } finally { connection?.disconnect() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GroceryScreen(onScan: () -> Unit) {
    val context = LocalContext.current
    val dao = remember { GroceryDatabase.get(context).shoppingDao() }
    val week = remember { currentWeekKey() }
    val groceries by dao.itemsForWeek(week).collectAsState(initial = emptyList())
    var newName by remember { mutableStateOf("") }
    var newVariant by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var priceItem by remember { mutableStateOf<ShoppingItem?>(null) }
    var priceText by remember { mutableStateOf("") }
    var storeText by remember { mutableStateOf("Dirk") }
    var updatingPrices by remember { mutableStateOf(false) }
    var updateMessage by remember { mutableStateOf("") }

    val visibleItems = groceries.filter {
        it.name.contains(search, ignoreCase = true) || (it.ean?.contains(search) == true)
    }
    val purchasedCount = groceries.count { it.purchased }
    val totalCents = groceries.sumOf { (it.priceCents ?: 0) * it.quantity }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Slimme Boodschappen", fontWeight = FontWeight.Bold)
                        Text(week, style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            if (!updatingPrices) {
                                updatingPrices = true
                                kotlinx.coroutines.MainScope().launch {
                                    var updated = 0
                                    groceries.filter { !it.purchased }.forEach { item ->
                                        val match = withContext(Dispatchers.IO) {
                                            // Calls are sequential and limited to items on this week's list.
                                            val retailers = listOf("dirk", "aldi", "plus", "albert-heijn", "jumbo")
                                            var found: ShoppingItem? = null
                                            for (retailer in retailers) {
                                                var conn: HttpURLConnection? = null
                                                try {
                                                    val q = URLEncoder.encode(item.ean ?: item.name, "UTF-8")
                                                    val u = URL("https://www.prijsprofeet.nl/api/v1/search?q=$q&retailer=$retailer&page_size=20")
                                                    conn = (u.openConnection() as HttpURLConnection).apply {
                                                        connectTimeout = 10000; readTimeout = 10000
                                                        setRequestProperty("User-Agent", "SlimmeBoodschappen/0.4 (Android)")
                                                    }
                                                    if (conn.responseCode != 200) continue
                                                    val root = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                                                    val rows = root.optJSONArray("results") ?: root.optJSONArray("items") ?: root.optJSONArray("products") ?: continue
                                                    for (i in 0 until rows.length()) {
                                                        val row = rows.optJSONObject(i) ?: continue
                                                        val ean = row.optString("ean")
                                                        val nm = row.optString("name", row.optString("product_name"))
                                                        val same = if (!item.ean.isNullOrBlank()) ean == item.ean else nm.contains(item.name, true)
                                                        val p = row.optDouble("price", Double.NaN)
                                                        val op = row.optDouble("original_price", Double.NaN)
                                                        val status = row.optString("promotion_status")
                                                        val deal = row.optBoolean("is_current_deal", false) || status == "active" || row.optBoolean("is_deal", false)
                                                        if (same && p.isFinite() && p > 0) {
                                                            found = item.copy(priceCents=(p*100).toInt(), store=retailer.replace("-", " "), isDeal=deal,
                                                                originalPriceCents=if(deal && op.isFinite() && op>p) (op*100).toInt() else null,
                                                                dealValidUntil=if (deal) row.optString("valid_until").takeUnless { it=="null" || it.isBlank() } else null)
                                                            break
                                                        }
                                                    }
                                                    if (found != null) break
                                                } catch (_: Exception) {
                                                } finally { conn?.disconnect() }
                                            }
                                            found
                                        }
                                        if (match != null) { dao.update(match); updated++ }
                                    }
                                    updateMessage = "$updated prijzen gevonden (regulier of aanbieding indien beschikbaar)"
                                    updatingPrices = false
                                }
                            }
                        },
                        enabled = !updatingPrices
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Actuele prijzen bijwerken")
                    }
                    IconButton(onClick = onScan) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "EAN scannen")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, contentDescription = "Product toevoegen")
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("Deze week", style = MaterialTheme.typography.titleMedium)
                    Text("$purchasedCount van ${groceries.size} producten gekocht")
                    LinearProgressIndicator(
                        progress = { if (groceries.isEmpty()) 0f else purchasedCount.toFloat() / groceries.size },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Bekende subtotaal: ${String.format(Locale("nl", "NL"), "€ %.2f", totalCents / 100.0)}",
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Zoek product of EAN") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
            )

            if (updatingPrices || updateMessage.isNotBlank()) {
                Text(if (updatingPrices) "Prijzen en aanbiedingen bijwerken…" else updateMessage,
                    style = MaterialTheme.typography.labelSmall)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onScan, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("EAN scannen")
                }
                OutlinedButton(onClick = { showAdd = true }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Zelf toevoegen")
                }
            }

            if (groceries.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("Je lijst is nog leeg. Scan een barcode of voeg een product toe.")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(visibleItems, key = { it.id }) { item ->
                        GroceryRow(
                            item = item,
                            onToggle = {
                                kotlinx.coroutines.MainScope().launch {
                                    dao.update(item.copy(purchased = !item.purchased))
                                }
                            },
                            onDelete = {
                                kotlinx.coroutines.MainScope().launch { dao.delete(item) }
                            },
                            onQuantityChange = { newQuantity ->
                                kotlinx.coroutines.MainScope().launch {
                                    dao.update(item.copy(quantity = newQuantity.coerceAtLeast(1)))
                                }
                            },
                            onPriceClick = {
                                priceItem = item
                                priceText = item.priceCents?.let { String.format(Locale.US, "%.2f", it / 100.0) } ?: ""
                                storeText = item.store ?: "Dirk"
                            }
                        )
                    }
                }
            }
            Text("Prijzen en aanbiedingen zoeken · productfoto’s via Open Food Facts", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Product toevoegen") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Product of productgroep") },
                        placeholder = { Text("Bijvoorbeeld jam") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newVariant,
                        onValueChange = { newVariant = it },
                        label = { Text("Variant / smaak / soort (optioneel)") },
                        placeholder = { Text("Bijvoorbeeld aardbei, 450 g") },
                        singleLine = true
                    )
                    if (newName.contains("jam", ignoreCase = true)) {
                        Text("Veelgekozen smaken", style = MaterialTheme.typography.labelMedium)
                        val flavors = listOf("Aardbei", "Abrikoos", "Kersen", "Bosvruchten", "Framboos", "Vier vruchten")
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            flavors.chunked(2).forEach { pair ->
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    pair.forEach { flavor ->
                                        AssistChip(
                                            onClick = { newVariant = flavor },
                                            label = { Text(flavor) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Text(
                        "Je kunt ook zelf een merk, smaak of verpakking invullen.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val baseName = newName.trim()
                    val variant = newVariant.trim()
                    val name = if (variant.isNotEmpty()) "$baseName · $variant" else baseName
                    if (baseName.isNotEmpty()) {
                        kotlinx.coroutines.MainScope().launch {
                            val image = lookupImageByName(name)
                            dao.insert(ShoppingItem(weekKey = week, name = name, imageUrl = image))
                        }
                        newName = ""
                        newVariant = ""
                        showAdd = false
                    }
                }) { Text("Toevoegen") }
            },
            dismissButton = {
                TextButton(onClick = { showAdd = false }) { Text("Annuleren") }
            }
        )
    }

    if (priceItem != null) {
        AlertDialog(
            onDismissRequest = { priceItem = null },
            title = { Text("Prijs instellen") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(priceItem?.name ?: "")
                    OutlinedButton(
                        onClick = {
                            val query = priceItem?.name.orEmpty()
                            val domain = when (storeText) {
                                "Dirk" -> "dirk.nl"
                                "Aldi" -> "aldi.nl"
                                "PLUS" -> "plus.nl"
                                "Albert Heijn" -> "ah.nl"
                                else -> "jumbo.com"
                            }
                            val searchUrl = "https://www.google.com/search?q=" +
                                URLEncoder.encode("site:$domain $query prijs", "UTF-8")
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl)))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Zoek actuele prijs bij $storeText")
                    }
                    Text(
                        "Controleer de productvariant en vul de gevonden prijs hieronder in.",
                        style = MaterialTheme.typography.labelSmall
                    )
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it.replace(',', '.') },
                        label = { Text("Prijs in euro's") },
                        placeholder = { Text("bijv. 1.49") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                    Text("Supermarkt", style = MaterialTheme.typography.labelMedium)
                    listOf("Dirk", "Aldi", "PLUS", "Albert Heijn", "Jumbo").forEach { store ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = storeText == store,
                                onClick = { storeText = store }
                            )
                            Text(store)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val item = priceItem
                    val amount = priceText.toDoubleOrNull()
                    if (item != null && amount != null && amount >= 0.0) {
                        kotlinx.coroutines.MainScope().launch {
                            dao.update(item.copy(priceCents = (amount * 100).toInt(), store = storeText))
                        }
                        priceItem = null
                    }
                }) { Text("Opslaan") }
            },
            dismissButton = {
                TextButton(onClick = { priceItem = null }) { Text("Annuleren") }
            }
        )
    }

}

@Composable
private fun GroceryRow(
    item: ShoppingItem,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
    onQuantityChange: (Int) -> Unit,
    onPriceClick: () -> Unit
) {
    Card(
        modifier = if (item.isDeal) Modifier.border(2.dp, Color(0xFFFFC107), MaterialTheme.shapes.medium)
                   else Modifier
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = item.purchased, onCheckedChange = { onToggle() })
            if (!item.imageUrl.isNullOrBlank()) AsyncImage(model = item.imageUrl, contentDescription = item.name, modifier = Modifier.size(64.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    item.name,
                    fontWeight = FontWeight.SemiBold,
                    color = if (item.purchased) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onSurface
                )
                if (item.ean != null) {
                    Text("EAN: ${item.ean}", style = MaterialTheme.typography.labelSmall)
                }
                if (item.priceCents == null) {
                    Text("Prijs nog niet ingevoerd", style = MaterialTheme.typography.labelSmall)
                } else {
                    Text(
                        String.format(Locale("nl", "NL"), "€ %.2f per stuk · %s", item.priceCents / 100.0, item.store ?: "Winkel onbekend"),
                        style = MaterialTheme.typography.labelSmall
                    )
                    if (!item.isDeal) {
                        Text("Indicatieve richtprijs · controleer de actuele winkelprijs", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        String.format(Locale("nl", "NL"), "Totaal: € %.2f", item.priceCents * item.quantity / 100.0),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                if (item.isDeal) {
                    Text(
                        buildString {
                            append("AANBIEDING")
                            item.originalPriceCents?.let { append(String.format(Locale("nl", "NL"), " · was € %.2f", it / 100.0)) }
                            item.dealValidUntil?.let { append(" · t/m $it") }
                        },
                        color = Color(0xFF9A6B00),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                TextButton(onClick = onPriceClick, contentPadding = PaddingValues(0.dp)) {
                    Text(if (item.priceCents == null) "Prijs toevoegen" else "Prijs wijzigen")
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    OutlinedButton(
                        onClick = { if (item.quantity > 1) onQuantityChange(item.quantity - 1) },
                        enabled = item.quantity > 1,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier.height(36.dp)
                    ) { Text("−") }
                    Text(
                        item.quantity.toString(),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    OutlinedButton(
                        onClick = { onQuantityChange(item.quantity + 1) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier.height(36.dp)
                    ) { Text("+") }
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Verwijderen")
            }
        }
    }
}
