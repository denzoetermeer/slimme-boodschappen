# Slimme Boodschappen – Android startversie

Dit is een afzonderlijk Android-project voor de boodschappenapp.

## Wat zit in deze eerste basisversie?
- Lokale weeklijst (ISO-weeknummer) met Room-database.
- Product handmatig toevoegen en verwijderen.
- Producten afvinken als gekocht.
- Zoeken op productnaam of EAN.
- EAN/UPC-barcode scannen via Google Play Services Code Scanner.
- Basis voor productprijsvelden en winkelherkomst.

## Nog niet aangesloten
De volgende onderdelen zijn bewust nog niet als werkend gepresenteerd:
- Live productcatalogi en prijzen van Dirk, Aldi, PLUS, Albert Heijn en Jumbo.
- Automatische productnaam-resolutie via EAN.
- Voorraadfoto's en AI-herkenning.
- Leren van aankoop- en verbruikspatronen.
- Volledige weekarchief-/historie-interface.

Deze onderdelen vereisen aanvullende productdatabronnen, prijsintegraties en de voorraad-/leerlogica.

## APK bouwen via GitHub Actions (zonder Windows-pc)
1. Maak op GitHub een nieuwe lege repository aan, bijvoorbeeld `slimme-boodschappen`.
2. Upload de inhoud van deze ZIP naar de repository (de mapinhoud, niet de ZIP zelf).
3. Open het tabblad **Actions**.
4. Kies **Build Android APK** en druk op **Run workflow**.
5. Na een geslaagde build open je de run en download je bij **Artifacts** `SlimmeBoodschappen-debug`.
6. Pak het artifact uit op je telefoon en installeer `app-debug.apk`. Android kan vragen om installatie vanuit deze bron toe te staan.

## Technische notities
- Package: `nl.slimmeboodschappen`
- Minimaal Android 8.0 (API 26).
- Kotlin, Jetpack Compose, Room en Google ML Kit Code Scanner.
- Scanner gebruikt Google Play Services en kan bij de eerste keer scannen de benodigde module downloaden.

## Belangrijke implementatienotitie
De scanner is bedoeld voor het scannen van EAN/UPC-codes. In de huidige basisversie wordt het gescande nummer aan de lijst toegevoegd als `Onbekend product`; een productcatalogus-koppeling om naam en prijs automatisch op te halen volgt in een latere fase.


## Versie 0.2 – EAN-productherkenning
Na het scannen zoekt de app de barcode op via de Open Food Facts Product API. Als er een match is, vult de app productnaam, merk en inhoud in. Als er geen match of netwerkverbinding is, blijft het product als `Onbekend product` staan. Productprijzen worden hiermee niet opgehaald.


## Versie 0.5.0
- Handmatig product toevoegen met variant/smaak/soort.
- Snelle smaakkeuzes voor jam.
- Vanuit prijsinvoer rechtstreeks zoeken op de geselecteerde supermarktwebsite (Dirk eerst als standaard); controleer de juiste variant en voer de getoonde prijs handmatig in.
- Automatische reguliere prijsuitlezing uit de winkelwebsites is niet inbegrepen: de websites hebben geen stabiele, openbare prijs-API voor dit gebruik.


## Versie 0.7.0
- Aldi toegevoegd als winkeloptie.
- Automatische prijszoekvolgorde bevat nu ook Aldi (via de bestaande PrijsProfeet-koppeling).
- Handmatig zoeken opent resultaten beperkt tot `site:aldi.nl`.
- In het scherm voor handmatige prijsinvoer is Aldi als supermarkt te selecteren.

## Versie 0.8.0 – herstel afbeeldingen en release-ondertekening
- Versie verhoogd naar 0.8.0 (versionCode 7).
- Productafbeeldingen zoeken nu maximaal 10 Open Food Facts-resultaten en kiezen de best passende match met een beschikbare afbeelding, in plaats van alleen het eerste resultaat te gebruiken.
- Normale prijzen worden in de boodschappenlijst expliciet als indicatieve richtprijs getoond; aanbiedingen blijven apart herkenbaar.
- GitHub Actions bouwt voortaan een release-APK die met een vaste release-sleutel wordt ondertekend. Bewaar die sleutel veilig en gebruik hem voor alle volgende versies.
- Google wordt gebruikt als aanvullende zoekmogelijkheid via de bestaande handmatige winkelzoekknop. De app schraapt geen Google-resultaten automatisch; zulke resultaten zijn niet betrouwbaar genoeg om als actuele prijs op te slaan.

### Eenmalige configuratie voor ondertekening
Volg `RELEASE_SIGNING.md` en voeg de vier genoemde GitHub Actions secrets toe. Zonder deze secrets stopt de release-build bewust, zodat niet per ongeluk een APK met een wisselende sleutel wordt gemaakt.

### Nog nodig voor automatische updatecontrole
De app heeft nog een vaste GitHub-repository/releasepagina nodig om nieuwe versies te kunnen controleren. Configureer daarom nog geen updateknop op basis van een verzonnen repository. Geef de GitHub-repository-URL op om dit veilig aan de app te koppelen.
